<?php
$hostname = "localhost";
$bancodedados = "id21370988_cafegourmet";
$usuario = "id21370988_root";
$senha = "Fl@meng@198@";

$conn = mysqli_connect ($hostname, $usuario, $senha, $bancodedados);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "";


?>